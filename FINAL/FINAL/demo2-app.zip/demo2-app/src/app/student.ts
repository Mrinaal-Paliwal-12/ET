export class Student {

    rollno:number=0;
    studentName:string ="";
    courses:string="";
    constructor(r:number,n:string,c:string)
    {
        this.rollno= r;
        this.studentName=n;
        this.courses=c;
    }

}
